<div class="mb-3">
    
    <?php echo e(html()->label('Nombre de la Etiqueta', 'name')->class('form-label')); ?>

    <?php echo e(html()->text('name')
            ->class('form-control')
            ->placeholder('Ingrese el nombre de la etiqueta')
            ->value(old('name', $etiqueta->name))); ?>


    
    <?php echo e(html()->label('Seleccionar color', 'color')->class('form-label')); ?>

    <input type="color" class="form-control" name="color" value="<?php echo e(old('color', $etiqueta->color ?? '#ffffff')); ?>">  
      
     <!-- <select name="color" id="color" class="form-control">

        <?php $__currentLoopData = $coloresTailwind; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($key); ?>" <?php echo e(old('color', $etiqueta->color) == $key ? 'selected' : ''); ?>>
                <?php echo e($color); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>  -->

    
    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="text-danger"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH C:\xampp\htdocs\Blog\resources\views/admin/etiquetas/partials/form.blade.php ENDPATH**/ ?>