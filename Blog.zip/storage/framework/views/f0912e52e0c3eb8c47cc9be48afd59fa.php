

<?php $__env->startSection('title', 'StockInteligente'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Listados etiquetas:</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(session('mesagge')): ?>
<div class="alert alert-success">
    <strong><?php echo e(session('mesagge')); ?></strong>
</div>
<?php endif; ?>
<div class="card">
    <div class="card-header">
        <a href="<?php echo e(route('admin.etiquetas.create')); ?>" class="btn btn-success">Agregar Etiqueta</a>
    </div>
    <div class="card-body">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th></th>
                    <th>Nombre</th>
                    <th>Color</th>
                    <th colspan="2"></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $etiquetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etiqueta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($etiqueta->id); ?></td>
                    <td width="5px">
                        <?php
                        $color = $etiqueta->color ?? '#ffffff'; // Asigna blanco si no hay color
                        ?>
                        <div style="width: 20px; height: 20px; background-color: <?php echo e($etiqueta->color); ?>; border: 1px solid #000;"></div>
                    </td>
                    <td><?php echo e($etiqueta->name); ?></td>
                    <td><?php echo e($etiqueta->color); ?></td>
                    <td width="10px">
                        <a href="<?php echo e(route('admin.etiquetas.edit',$etiqueta)); ?>" class="btn btn-sm btn-primary">Editar</a>
                    </td>
                    <td width="10px">
                        <form action="<?php echo e(route('admin.etiquetas.destroy',$etiqueta)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button class="btn btn-danger btn-sm">Borrar</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    console.log("Hi, I'm using the Laravel-AdminLTE package!");
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Blog\resources\views/admin/etiquetas/index.blade.php ENDPATH**/ ?>