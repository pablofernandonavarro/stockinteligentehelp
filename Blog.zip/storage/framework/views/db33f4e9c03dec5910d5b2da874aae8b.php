<?php $__env->startSection('title', 'StockInteligente'); ?>

<?php $__env->startSection('content_header'); ?>
<h1 class="d-flex justify-content-center mx-auto my-auto">Stock Inteligente</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    console.log("Hi, I'm using the Laravel-AdminLTE package!");
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Blog\resources\views/admin/home.blade.php ENDPATH**/ ?>