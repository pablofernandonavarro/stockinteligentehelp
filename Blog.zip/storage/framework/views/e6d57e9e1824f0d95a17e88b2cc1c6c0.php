<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-screen-xl flex flex-wrap items-center justify-between mx-auto p-4">
        <h1 class="text-4xl font-bold text-gray-600"><?php echo e($post->name); ?></h1>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <!-- // * ---------- contenido Principal ---------------------------------------------------------------------------------- -->
            <div class="lg:col-span-2">
                <figure>
                    <?php if($post->image): ?>
                    <img class="w-full h-80 object-contain object-center" src="<?php echo e(Storage::url($post->image->url)); ?>" alt="<?php echo e($post->name); ?>">
                    <?php else: ?>
                    <img class="w-full h-72 object-contain object-center" src="<?php echo e(asset('/storage/CoreImages/SinPhoto.jpeg')); ?>" alt="Imagen predeterminada">
                    <?php endif; ?>
                </figure>
                <div class="text-lg text-gray-500 mb-2">
                    <?php echo $post->extract; ?>

                </div>
                <div class="text-base text-gray-500 mt-4">
                    <?php echo $post->body; ?>

                </div>
<hr>
            </div>

            <!-- // * ---------- contenido Relacionado ---------------------------------------------------------------------------------- -->
            <aside>
                <h1 class="text-2xl font-bold text-gray-600 mb-2">
                    Más en <?php echo e($post->category->name); ?>

                </h1>
                <ul>
                    <?php $__currentLoopData = $similares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $similar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="mb-4">
                        <a class="flex" href="<?php echo e(route('posts.show',$similar)); ?>">
                            <?php if($similar->image): ?>
                            <img class="w-35 h-20 object-contain object-center" src="<?php echo e(Storage::url($similar->image->url)); ?>" alt="<?php echo e($similar->name); ?>">
                            <?php else: ?>
                            <img class="w-35 h-20 object-contain object-center" src="<?php echo e(asset('storage/CoreImages/SinPhoto.jpeg')); ?>" alt="Imagen predeterminada">
                            <?php endif; ?>
                            <span class="ml-2 text-gray-600"><?php echo e($similar->name); ?></span>
                        </a>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </aside>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Blog\resources\views/posts/show.blade.php ENDPATH**/ ?>