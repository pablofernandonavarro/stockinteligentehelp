

<div class="form-group">
    <?php echo e(html()->label('Nombre de la Publicación', 'name')->class('form-label')); ?>

    <?php echo e(html()->text('name')->class('form-control')->placeholder('Ingrese el nombre de la Publicación')); ?>

    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class='text-danger'><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group">
    <?php echo e(html()->label('Slug', 'slug')->class('form-label')); ?>

    <?php echo e(html()->text('slug')->class('form-control')->placeholder('Slug generado automáticamente')->isReadonly()); ?>


    <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class='text-danger'><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group">
    <?php echo e(html()->label('Seleccionar categoria', 'category_id')->class('form-label')); ?>

    <?php echo e(html()->select('category_id', $categories,null)->class('form-control')); ?>

    <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class='text-danger'><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group">
    <p class="font-weight-bold">Etiquetas:</p>
    <?php $__currentLoopData = $etiquetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etiqueta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="form-check">
            
            <?php echo e(html()->checkbox('etiquetas[]', in_array($etiqueta->id, $post->etiquetas->pluck('id')->toArray()), $etiqueta->id)
                ->class('form-check-input')
                ->id('etiqueta_'.$etiqueta->id)); ?>

            <?php echo e(html()->label($etiqueta->name, 'etiqueta_'.$etiqueta->id)->class('form-check-label')); ?>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__errorArgs = ['etiquetas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-danger"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>


<div class="form-group py-3">
    <p class="font-weight-bold">Estado:</p>
    <label>
        <?php echo e(html()->radio('status',$checked=true, $value =1)->class('form-control')); ?>

        Borrador
    </label>
    <label>
        <?php echo e(html()->radio('status',$checked=false, $value =2)->class('form-control')); ?>

        Publicado
    </label>
    <br>
    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class='text-danger'><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<!-- * _______________________________________________      PHOTO ______________________________________________________________________________________ -->

<div class="row">
    <div class="col">
        <div class="image-wrapper"  id="file">
            <?php if($post->image): ?>
               <img src="<?php echo e(Storage::url($post->image->url)); ?>" alt="">
            <?php else: ?>
            <img src="<?php echo e(asset('storage\CoreImages\SinPhoto.jpeg')); ?>" alt="">
            
            <?php endif; ?>
        </div>
    </div>
    <div class="col">
        <div class="form-group">


            <?php echo e(html()->label('Imagen que se vera en la Publicación')); ?>

            <?php echo e(html()->file('file')->class('form-control')); ?>

             <br>
            <strong> Dimensiones de la Imagen :</strong>
            <p>Alto : 1024 px</p>
            <p>ancho : 610 px</p>
            <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class='text-danger'><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
</div>
</div>

<!-- * _______________________________________________      /PHOTO ______________________________________________________________________________________ -->
<div class="form-group">
<?php echo e(html()->label('Extracto:', 'extract')->class('form-label')); ?>

<?php echo e(html()->textarea('extract', null)->class('form-control')->id('extract')); ?>

<?php $__errorArgs = ['extract'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<span class='text-danger'><?php echo e($message); ?></span>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
<?php echo e(html()->label('Cuerpo del la Publicación:', 'body')->class('form-label')); ?>

<?php echo e(html()->textarea('body', null)->class('form-control')); ?>

</div>
<?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<span class='text-danger'><?php echo e($message); ?></span>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php /**PATH C:\xampp\htdocs\Blog\resources\views/admin/posts/partials/form.blade.php ENDPATH**/ ?>