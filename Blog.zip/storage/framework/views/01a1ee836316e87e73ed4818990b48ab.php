

<?php $__env->startSection('title', 'StockInteligente'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Crear nueva Etiqueta:</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <?php echo e(html()->form('POST', route('admin.etiquetas.store'))->class('form-horizontal')->open()); ?>


            <?php echo $__env->make('admin.etiquetas.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="mb-3">
                <?php echo e(html()->submit('Crear Categoria')->class('btn btn-success')); ?>

            </div>

            <?php echo e(html()->form()->close()); ?>

        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Blog\resources\views/admin/etiquetas/create.blade.php ENDPATH**/ ?>