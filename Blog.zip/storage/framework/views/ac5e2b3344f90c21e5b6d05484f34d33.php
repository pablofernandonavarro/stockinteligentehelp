

<?php $__env->startSection('title', 'Crear Publicación'); ?>

<?php $__env->startSection('content_header'); ?>
<h1 class="d-flex justify-content-center mx-auto my-auto">Crear Publicación</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <?php echo e(html()->form('POST', route('admin.posts.store'))->class('form-horizontal p-3')->autocomplete('off')->attributes(['enctype' => 'multipart/form-data', 'accept' => 'image/*'])->open()); ?>


    <?php echo e(html()->hidden('user_id', auth()->user()->id)); ?>


    <div class="form-group">
        <?php echo e(html()->label('Nombre de la Publicación', 'name')->class('form-label')); ?>

        <?php echo e(html()->text('name')->class('form-control')->placeholder('Ingrese el nombre de la Publicación')); ?>

        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class='text-danger'><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group">
        <?php echo e(html()->label('Slug', 'slug')->class('form-label')); ?>

        <?php echo e(html()->text('slug')->class('form-control')->placeholder('Slug generado automáticamente')->isReadonly()); ?>


        <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class='text-danger'><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group">
        <?php echo e(html()->label('Seleccionar categoria', 'category_id')->class('form-label')); ?>

        <?php echo e(html()->select('category_id', $categories,null)->class('form-control')); ?>

        <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class='text-danger'><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group">
        <p class="font-weight-bold">Etiquetas:</p>
        <?php $__currentLoopData = $etiquetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etiqueta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="form-check">
            <?php echo e(html()->checkbox('etiquetas[]', in_array($etiqueta->id, old('etiquetas', [])), $etiqueta->id)->class('form-check-input')->id('etiqueta_'.$etiqueta->id)); ?>

            <?php echo e(html()->label($etiqueta->name, 'etiqueta_'.$etiqueta->id)->class('form-check-label')); ?>

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php $__errorArgs = ['etiquetas_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class='text-danger'><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group py-3">
        <p class="font-weight-bold">Estado:</p>
        <label>
            <?php echo e(html()->radio('status',$checked=true, $value =1)->class('form-control')); ?>

            Borrador
        </label>
        <label>
            <?php echo e(html()->radio('status',$checked=false, $value =2)->class('form-control')); ?>

            Publicado
        </label>
        <br>
        <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class='text-danger'><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <!-- * _______________________________________________      PHOTO ______________________________________________________________________________________ -->

    <div class="row">
        <div class="col">
            <div class="image-wrapper">
                <img src="<?php echo e(asset('storage\CoreImages\SinPhoto.jpeg')); ?>" alt="" id="picture">
            </div>
        </div>
        <div class="col">
            <div class="form-group">


                <?php echo e(html()->label('Imagen que se vera en la Publicación')); ?>

                <?php echo e(html()->file('file')->class('form-control')); ?>

                 <br>
                <strong> Dimensiones de la Imagen :</strong>
                <p>Alto : 1024 px</p>
                <p>ancho : 610 px</p>
                <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class='text-danger'><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>
</div>

<!-- * _______________________________________________      /PHOTO ______________________________________________________________________________________ -->
<div class="form-group">
    <?php echo e(html()->label('Extracto:', 'extract')->class('form-label')); ?>

    <?php echo e(html()->textarea('extract', null)->class('form-control')->id('extract')); ?>

    <?php $__errorArgs = ['extract'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class='text-danger'><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
    <?php echo e(html()->label('Cuerpo del la Publicación:', 'body')->class('form-label')); ?>

    <?php echo e(html()->textarea('body', null)->class('form-control')); ?>

</div>
<?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<span class='text-danger'><?php echo e($message); ?></span>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>



<div class="mb-3">
    <?php echo e(html()->submit('Crear Publicación')->class('btn btn-secondary float-right my-2 mx-2')); ?>

</div>

<?php echo e(html()->form()->close()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
    .image-wrapper {
        position: relative;
        padding-bottom: 10%;
    }

    .imagen-wrapper-img {
        position: absolute;
        object-fit: cover;
        height: 100%;
    }
</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('vendor/jQuery-Plugin-stringToSlug-1.3/jquery.stringToSlug.min.js')); ?>"></script>
<script src="https://cdn.ckeditor.com/ckeditor5/24.0.0/classic/ckeditor.js"></script>
<script>
    ClassicEditor
        .create(document.querySelector("#extract"))
        .catch(error => {
            console.log(error);
        });
    ClassicEditor
        .create(document.querySelector("#body"))
        .catch(error => {
            console.log(error);
        });

    // cambiar imagen
    document.getElementById("file").addEventListener('change', cambiarImagen);

    function cambiarImagen() {
        var file = event.target.files[0];
        var reader = new FileReader();
        reader.onload = (event) => {
            document.getElementById("picture").setAttribute('src', event.target.result);
        }
        reader.readAsDataURL(file);
    }
</script>
<script>
    $(document).ready(function() {
        $("#name").stringToSlug({
            setEvents: 'keyup keydown blur',
            getPut: '#slug',
            space: '-'
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Blog\resources\views/admin/posts/create.blade.php ENDPATH**/ ?>