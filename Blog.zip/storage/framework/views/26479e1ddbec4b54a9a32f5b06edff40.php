<div class="card">
    <div class="card-header">
        <?php echo e($search); ?>

        <input wire:model.live="search" type="search" class="form-control"
            placeholder="Ingrese el nombre de la publicacion a buscar"/>

    </div>

    <div class="card-body">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>id</th>
                    <th>Nombre</th>
                    <th colspan="2"class="d-flex justify-content-center">accion</th>
                </tr>
            </thead>
            <tbody>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($post->id); ?></td>
                        <td><?php echo e($post->name); ?></td>
                        <td with="10px">
                            <a class="btn btn-primary btn-sm"href="<?php echo e(route('admin.posts.edit', $post)); ?>">Editar</a>
                        </td>
                        <td with="10px">
                            <form action="<?php echo e(route('admin.posts.destroy', $post)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger btn-sm">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>
    </div>
     <div class="card-footer">
        <?php echo e($posts->links()); ?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Blog\resources\views/livewire/admin/postsindex.blade.php ENDPATH**/ ?>