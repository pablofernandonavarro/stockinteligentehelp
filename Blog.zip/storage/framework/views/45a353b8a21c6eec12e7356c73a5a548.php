

<?php $__env->startSection('title', 'StockInteligente'); ?>

<?php $__env->startSection('content_header'); ?>
<h1 class="d-flex justify-content-center mx-auto my-auto">Editar Rol: <?php echo e($role->name); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <div class="card-body">
            
            <?php echo e(html()->form('PUT', route('admin.roles.update', $role->id))->class('form-horizontal')->open()); ?>


            
            <?php echo e(html()->label('Nombre del Role', 'name')->class('form-label')); ?>

            <?php echo e(html()->text('name', $role->name)
            ->class('form-control mb-3')
            ->placeholder('Ingrese el nombre del rol')); ?>


            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger">
                <?php echo e($message); ?>

            </small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <h1>Lista de Permisos:</h1>
            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="">
                <label for="">
                    
                    <?php echo e(html()->checkbox('permissions[]', $role->permissions->contains($permission->id), $permission->id)->class('mr-2')); ?>

                    <?php echo e($permission->description); ?>

                </label>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="mt-3">
                <?php echo e(html()->submit('Actualizar Rol')->class('btn btn-secondary')); ?>

            </div>

            <?php echo e(html()->form()->close()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Blog\resources\views/admin/roles/edit.blade.php ENDPATH**/ ?>