

<?php $__env->startSection('title', 'Usuarios'); ?>

<?php $__env->startSection('content_header'); ?>
<h1 class="d-flex justify-content-center mx-auto my-auto">Asignar un Rol:</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(session('message')): ?>
    <div class="alert alert-success">
        <strong><?php echo e(session('message')); ?></strong>
    </div>
<?php endif; ?>

<div class="card">
    <div class="card-body">
        <p class="h5">Nombre</p>
        <p class="form-control"><?php echo e($user->name); ?></p>

        <h2>Listado de Roles</h2>

        <?php echo html()->modelForm($user, 'PUT', route('admin.users.update', $user))
            ->class('form-horizontal p-3')
            ->autocomplete('off')
            ->open(); ?>

        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="form-group">
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-check">
                    <?php echo e(html()->checkbox('roles[]', in_array($role->id, $user->roles->pluck('id')->toArray()), $role->id)
                        ->class('form-check-input')
                        ->id('role_' . $role->id)); ?>

                    <?php echo e(html()->label($role->name, 'role_' . $role->id)->class('form-check-label')); ?>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="mb-3">
                <?php echo e(html()->submit('Asignar Rol')->class('btn btn-secondary float-right my-2 mx-2')); ?>

            </div>

            <?php $__errorArgs = ['roles'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <?php echo e(html()->form()->close()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Blog\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>