

<?php $__env->startSection('title', 'Ver Publicación'); ?>

<?php $__env->startSection('content_header'); ?>
<h1 class="d-flex justify-content-center mx-auto my-auto">Ver Publicación</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card p-3">

    <div class="form-group">
        <label class="form-label">Nombre de la Publicación</label>
        <p class="form-control"><?php echo e($post->name); ?></p>
    </div>

    <div class="form-group">
        <label class="form-label">Slug</label>
        <p class="form-control"><?php echo e($post->slug); ?></p>
    </div>

    <div class="form-group">
        <label class="form-label">Categoría</label>
        <p class="form-control"><?php echo e($post->category->name); ?></p>
    </div>

    <div class="form-group">
        <p class="font-weight-bold">Etiquetas:</p>
        <?php $__currentLoopData = $post->etiquetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etiqueta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <span class="badge badge-primary"><?php echo e($etiqueta->name); ?></span>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="form-group py-3">
        <p class="font-weight-bold">Estado:</p>
        <p class="form-control"><?php echo e($post->status == 1 ? 'Borrador' : 'Publicado'); ?></p>
    </div>

    <!-- Imagen -->
    <div class="row">
        <div class="col">
            <div class="image-wrapper">
                <img src="<?php echo e($post->image ? Storage::url($post->image->url) : asset('storage/CoreImages/SinPhoto.jpeg')); ?>" alt="" id="picture">
            </div>
        </div>
        <div class="col">
            <div class="form-group">
                <strong>Dimensiones de la Imagen:</strong>
                <p>Alto: 1024 px</p>
                <p>Ancho: 610 px</p>
            </div>
        </div>
    </div>

    <div class="form-group">
        <?php echo e(html()->label('Extracto:', 'extract')->class('form-label')); ?>

        <?php echo e(html()->textarea('extract', $post->extract)->class('form-control')->id('extract')); ?>

        <?php $__errorArgs = ['extract'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class='text-danger'><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-group">
        <?php echo e(html()->label('Extracto:', 'extract')->class('form-label')); ?>

        <?php echo e(html()->textarea('extract', $post->body)->class('form-control')->id('body')); ?>

        <?php $__errorArgs = ['extract'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class='text-danger'><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
    .image-wrapper {
        position: relative;
        padding-bottom: 10%;
    }

    .imagen-wrapper-img {
        position: absolute;
        object-fit: cover;
        height: 100%;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://cdn.ckeditor.com/ckeditor5/24.0.0/classic/ckeditor.js"></script>
<script>
    
    ClassicEditor
        .create(document.querySelector("#extract"))
        .catch(error => {
            console.log(error);
        });
    ClassicEditor
        .create(document.querySelector("#body"))
        .catch(error => {
            console.log(error);
        });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Blog\resources\views/admin/posts/show.blade.php ENDPATH**/ ?>