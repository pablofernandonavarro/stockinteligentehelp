<?php $__env->startSection('title', 'Listado Publicaciones'); ?>

<?php $__env->startSection('content_header'); ?>
<a href="<?php echo e(route('admin.posts.create')); ?>" class="btn btn-secondary btn-sm float-right">Crear una publicacion</a>
<h4 class="">Listado de Publicaciones</h4>
<?php if(session('mesagge')): ?>
<div class="alert alert-success">
    <strong><?php echo e(session('mesagge')); ?></strong>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split("admin.posts-index");

$__html = app('livewire')->mount($__name, $__params, 'lw-2348731065-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Blog\resources\views/admin/posts/index.blade.php ENDPATH**/ ?>