

<?php $__env->startSection('title', 'StockInteligente'); ?>

<?php $__env->startSection('content_header'); ?>
<?php if(session('info')): ?>
  <div class="alert alert-success">
    <span><?php echo e(session('info')); ?></span>
  </div>
<?php endif; ?>

<a href="<?php echo e(route('admin.roles.create')); ?>" class="btn  btn-secondary float-right">Crear Nuevo Rol:</a>
<h1 class="d-flex justify-content-center mx-auto my-auto">Lista Roles :</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



<div class="card">
    <table class="table table-striped">
        <thead>
            <tr>
              <th>Id</th>
              <th>Role</th>
              <th colspan="2"></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($role->id); ?></td>
            <td><?php echo e($role->name); ?></td>
            <td width="10px">
                <a href="<?php echo e(route('admin.roles.edit',$role)); ?>" class="btn btn-primary btn-sm">Editar</a>
            </td>
            <td width="10px">
                <form action="<?php echo e(route('admin.roles.destroy',$role)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
                </form>
            </td>
          </tr>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Blog\resources\views/admin/roles/index.blade.php ENDPATH**/ ?>