<div>
    <div class="card">
        <div class="card-header">
            <input wire:model.live="search" class="form-control" placeholder="Ingrese el nombre de un Usuario" autofocus />
        </div>
        <!--[if BLOCK]><![endif]--><?php if($users->count()): ?>


        <div class="card-body">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>id</th>
                        <th>Nombre</th>
                        <th>Email</th>
                        <th>Accion</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td with="10px">
                            <a href="<?php echo e(route('admin.users.edit',$user)); ?>" class="btn btn-primary btn-sm">Editar</a>
                        </td>
                        <td with="10px">
                            <form action="<?php echo e(route('admin.users.destroy',$user)); ?>">
                                <button class="btn btn-danger btn-sm">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </tbody>
            </table>
        </div>
        <div class="card-footer">
            <?php echo e($users->links()); ?>

        </div>
        <?php else: ?>
        <div class="card-body">
            <strong>No hay Registros!!</strong>
        </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    </div>
</div><?php /**PATH C:\xampp\htdocs\Blog\resources\views/livewire/admin/users-index.blade.php ENDPATH**/ ?>