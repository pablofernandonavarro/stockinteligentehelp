<?php $__env->startSection('title', 'StockInteligente'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Crear nueva categoria:</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <?php echo e(html()->form('POST', route('admin.categories.store'))->class('form-horizontal')->open()); ?>


            <div class="mb-3">
                <?php echo e(html()->label('Nombre de la categoría', 'category_name')->class('form-label')); ?>

                <?php echo e(html()->text('name')->class('form-control')->placeholder('Ingrese el nombre de la categoría')); ?>

            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class= 'text-danger'><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


            </div>

            <div class="mb-3">
                <?php echo e(html()->submit('Crear Categoria')->class('btn btn-success')); ?>

            </div>

            <?php echo e(html()->form()->close()); ?>

        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Blog\resources\views/admin/categories/create.blade.php ENDPATH**/ ?>