<?php

declare(strict_types=1);

return [
    'next'     => 'Далі &raquo;',
    'previous' => '&laquo; Назад',
];
