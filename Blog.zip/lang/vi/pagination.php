<?php

declare(strict_types=1);

return [
    'next'     => 'Trang sau &raquo;',
    'previous' => '&laquo; Trang trước',
];
