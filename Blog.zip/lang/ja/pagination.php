<?php

declare(strict_types=1);

return [
    'next'     => '次へ &raquo;',
    'previous' => '&laquo; 前へ',
];
