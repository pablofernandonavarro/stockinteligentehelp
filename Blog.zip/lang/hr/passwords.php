<?php

declare(strict_types=1);

return [
    'reset'     => 'Lozinka je ponovno postavljena!',
    'sent'      => 'E-mail sa poveznicom za ponovno postavljanje lozinke je poslan!',
    'throttled' => 'Molimo pričekajte prije ponovnog pokušaja!',
    'token'     => 'Oznaka za ponovno postavljanje lozinke više nije važeća.',
    'user'      => 'Korisnik s navedenom e-mail adresom nije pronađen.',
];
