<?php

declare(strict_types=1);

return [
    'failed'   => 'Prihlasovacie údaje nie sú správne.',
    'password' => 'Heslo nie je správne',
    'throttle' => 'Prekročený limit pokusov. Skúste to znova o :seconds sekúnd.',
];
