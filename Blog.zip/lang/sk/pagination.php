<?php

declare(strict_types=1);

return [
    'next'     => 'Nasledujúca &raquo;',
    'previous' => '&laquo; Predchádzajúca',
];
