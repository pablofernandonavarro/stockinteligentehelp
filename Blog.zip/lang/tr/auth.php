<?php

declare(strict_types=1);

return [
    'failed'   => 'Bu kimlik bilgileri kayıtlarımızla eşleşmiyor.',
    'password' => 'Parola geçersiz.',
    'throttle' => 'Çok fazla giriş denemesi. :seconds saniye sonra lütfen tekrar deneyin.',
];
