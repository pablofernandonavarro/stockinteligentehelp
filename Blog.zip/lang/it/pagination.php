<?php

declare(strict_types=1);

return [
    'next'     => 'Successivo &raquo;',
    'previous' => '&laquo; Precedente',
];
