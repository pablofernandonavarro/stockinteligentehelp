<?php

declare(strict_types=1);

return [
    'next'     => 'পরবর্তী &raquo;',
    'previous' => '&laquo; পুর্ববর্তী',
];
